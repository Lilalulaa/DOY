function Petinfo(props){
    const{animal, age, bi, color} = props

    return 
    <div>
    <h1 style={{ backgroundImage: 'url (' + bi + ')', color: color}}>
        My cute {animal}. He is {age}  years old.</h1>
     </div>
}

export default Petinfo