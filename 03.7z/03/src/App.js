import './App.css'
import Petinfo from './components/Petinfo'

function App() {
  return (<div className="App">
  <Petinfo 
  animal="cat" 
  age= {3} 
  color = "pink"
  bi="https://img.freepik.com/free-vector/gradient-spheres-background_52683-76367.jpg"
  
  >

  </Petinfo>
  
  
  <Petinfo 
  animal="dog" 
  age= {6} 
  bi="https://img.freepik.com/free-vector/gradient-spheres-background_52683-76367.jpg"
  >

  </Petinfo>
  </div>)
}

export default App
